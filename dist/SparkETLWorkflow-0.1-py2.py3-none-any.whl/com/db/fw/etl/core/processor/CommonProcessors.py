from com.db.fw.etl.core.common.Task import Task


class BaseProcessor(Task):
    def __init__(self, task_name,type):
        super.__init__(self,task_name,type)






from pyspark.sql import SparkSession
from pyspark import *


# spark = SparkSession.builder.getOrCreate()
# df = spark.range(100).show()
# df.select.write.save("namesAndAges.parquet", format="parquet")


